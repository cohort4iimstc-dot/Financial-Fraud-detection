# =========================
# 1. Import Libraries
# =========================
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import numpy as np
import pickle
import psycopg2

# =========================
# 2. Initialize App
# =========================
app = FastAPI()

# =========================
# 3. Enable CORS (React)
# =========================
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],   # allow frontend
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =========================
# 4. Load ML Model
# =========================
model = pickle.load(open("fraud_model.pkl", "rb"))

# =========================
# 5. Connect PostgreSQL
# =========================
conn = psycopg2.connect(
    database="fraud_detection",
    user="postgres",
    password="Chai@2004",   # 🔥 your password
    host="localhost",
    port="5432"
)

cursor = conn.cursor()

print("✅ Database Connected")

# =========================
# 6. Home Route
# =========================
@app.get("/")
def home():
    return {"message": "Fraud Detection API Running"}

# =========================
# 7. Prediction API
# =========================
@app.post("/predict")
def predict():
    try:
        import pandas as pd
        import numpy as np

        cursor = conn.cursor()

        # 🔥 1. Get latest transaction from DB
        query = """
        SELECT v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,
               v11,v12,v13,v14,v15,v16,v17,v18,v19,v20,
               v21,v22,v23,v24,v25,v26,v27,v28,amount
        FROM transactions1
        ORDER BY transaction_id DESC
        LIMIT 1
        """

        df = pd.read_sql(query, conn)

        # 🔥 2. Add Time column (since model expects it)
        df["Time"] = 0

        # 🔥 3. Arrange features correctly
        feature_cols = ["Time"] + [f"v{i}" for i in range(1, 29)] + ["amount"]

        X = df[feature_cols]

        # 🔥 4. Predict
        prediction = int(model.predict(X)[0])
        probability = float(model.predict_proba(X)[0][1])

        result_text = "⚠️ Fraud Detected" if prediction == 1 else "✅ Legitimate"

        # 🔥 5. Store result
        cursor.execute("""
            INSERT INTO model_predictions (transaction_id, model_name, predicted_class, fraud_probability)
            VALUES (%s, %s, %s, %s)
        """, (
            int(pd.read_sql("SELECT MAX(transaction_id) FROM transactions1", conn).iloc[0,0]),
            "random_forest",
            prediction,
            probability
        ))

        conn.commit()

        # 🔥 6. Return response
        return {
            "result": result_text,
            "probability": round(probability, 4)
        }

    except Exception as e:
        return {"error": str(e)}

# =========================
# 8. Get Prediction History
# =========================
@app.get("/history")
def get_history():

    cursor.execute("""
        SELECT prediction_id, model_name, predicted_class, fraud_probability, predicted_at
        FROM model_predictions
        ORDER BY prediction_id DESC
        LIMIT 10
    """)

    rows = cursor.fetchall()

    result = []
    for row in rows:
        result.append({
            "id": row[0],
            "model": row[1],
            "prediction": "⚠️ Fraud" if row[2] == 1 else "✅ Legitimate",
            "probability": row[3],
            "time": str(row[4])
        })

    return result

# =========================
# 9. Close Connection (Optional)
# =========================
@app.on_event("shutdown")
def shutdown():
    cursor.close()
    conn.close()
    print("❌ Database Connection Closed")